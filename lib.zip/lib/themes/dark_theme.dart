import 'package:flutter/material.dart';

final ThemeData darkTheme = ThemeData.dark().copyWith(
  primaryColor: Colors.teal,
  appBarTheme: AppBarTheme(color: Colors.teal),
);
