import 'package:flutter/material.dart';

final ThemeData lightTheme = ThemeData.light().copyWith(
  primaryColor: Colors.blue,
  appBarTheme: AppBarTheme(color: Colors.blue),
);
