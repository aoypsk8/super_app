import 'package:get/get.dart';

class AppTranslations extends Translations {
  @override
  Map<String, Map<String, String>> get keys => {
        'en': {
          'hello': 'Hello',
          'change_language': 'Change Language',
        },
        'lo': {
          'hello': 'ສະບາຍດີ',
          'change_language': 'ປ່ຽນພາສາ',
        },
        'zh': {
          'hello': '你好',
          'change_language': '更改语言',
        },
        'vi': {
          'hello': 'Xin chào',
          'change_language': 'Thay đổi ngôn ngữ',
        },
      };
}
